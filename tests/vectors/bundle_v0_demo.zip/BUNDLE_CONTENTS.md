# Bundle Contents

created_at: 2026-01-01T00:00:00Z
timeline_id: tl_bundle_demo
epoch_id: epoch-demo
protocol_version: claw-v1
api_version: v1
notes_included: false

included_artifacts:
- evidence/timeline.json
- frozen_manifest (embedded in evidence/timeline.json)
- receipt.json
- evidence/attestation_esign_1.json
- evidence/attestation_liability_2.json

boundary:
- Evidence-only. Not legal advice.
- Not enforcement or adjudication.
