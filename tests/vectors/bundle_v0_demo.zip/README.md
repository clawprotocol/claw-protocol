# CLAW Bundle v0

This bundle is evidence-only and non-binding.

Verification is cryptographic and file-based. Run verify.py for authoritative verification.
